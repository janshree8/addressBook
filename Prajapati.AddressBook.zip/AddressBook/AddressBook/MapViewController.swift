//
//  MapViewController.swift
//  AddressBook
//
//  Created by Janshree Prajapati on 6/30/21.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate{

    @IBOutlet var mapView: MKMapView!
    
    var Lake : Lakes!
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            
            
            mapView.showsCompass = true
            mapView.showsScale = true
            mapView.showsTraffic = true
 
            let identifier = "MyPin"
            if annotation.isKind(of: MKUserLocation.self){
                return nil
            }
        
        var annotationView:MKPinAnnotationView? = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView
        
        if annotationView == nil{
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView?.canShowCallout = true
        }
            let leftIconView = UIImageView(frame: CGRect.init(x:0, y:0, width: 53, height: 53))
            
            leftIconView.image = UIImage(named: Lake.image)
            
            //annotationView?.image = leftIconView.image
            annotationView?.leftCalloutAccessoryView = leftIconView
            return annotationView
            //annotationView!.annotation = annotation
           
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString( Lake.address ,
        completionHandler: { placemarks, error in
            if error != nil{
                print(error)
            return
            }
            if let placemarks = placemarks{
                let placemark = placemarks[0]
                //creating Pin annotation
                let annotation = MKPointAnnotation()
                //display the annotation
                annotation.title = self.Lake.titles
                annotation.subtitle = self.Lake.address
                
                //annotation = self.Lake.image
            
                if let location = placemark.location {
                    annotation.coordinate = location.coordinate
                    self.mapView.addAnnotation(annotation)
                    self.mapView.showAnnotations([annotation], animated: true)
                    self.mapView.selectAnnotation(annotation, animated: true)
                    /*
                    let region = MKCoordinateRegion(center: annotation.coordinate, latitudinalMeters: 250, longitudinalMeters: 250)
                    self.mapView.setRegion(region, animated: false)
 */
                }
            }}) }
        
    
}

        
        
    /*
    let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(showMap))
        
    mapView.addGestureRecognizer(tapGestureRecognizer)
    // Do any additional setup after loading the view.

    }

        func showMap() {
        performSegue(withIdentifier: "showMap", sender: self)
    }
         */
   
   // let coordinate = placemark.location?.coordinate
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */





