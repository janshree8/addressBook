//
//  Lakes.swift
//  AddressBook
//
//  Created by Shiwangi Koirala on 6/30/21.
//

import Foundation

class Lakes{
    var titles = ""
    var address = ""
    var image = ""
    var location = ""
    
    init(titles: String, location: String, address: String, image: String){
        self.titles = titles
        self.address = address
        self.image = image
        self.location = location
        
        
    }
    
    
    
}
