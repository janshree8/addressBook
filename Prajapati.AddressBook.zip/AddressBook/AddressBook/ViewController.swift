//
//  ViewController.swift
//  AddressBook
//
//  Created by Shiwangi Koirala on 6/30/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    

    @IBOutlet var tableView: UITableView!
    
    var addressBook: [Lakes] = [
    
        Lakes(titles: "Lake Ray Hubbard", location: "Northeast Dallas, TX", address: "6775 Miller Rd, Rowlett, TX, 75088", image: "hubbard.jpeg"),
        
        Lakes(titles: "White Rock Lake", location: "East Dallas, TX", address: "8300 E Lawther Dr, Dallas, TX 75218", image: "Whiterock.jpeg"),
        
        Lakes(titles: "Grapevine Lake", location: "Grapevine", address: "880 Simmons Rd, Flower Mound, 75022", image: "Grapevine.jpeg"),
        
        Lakes(titles: "Bachman Lake", location: "Northwest Dallas, TX", address: "2530 Webb Chapel Extension Dallas, TX 75220", image: "Bachman.jpeg"),
        
        Lakes(titles: "Lake Tawakoni", location: "West Tawakoni, TX", address: "10822 FM 2475. Wills Point, TX 75169", image: "Tawakoni.jpeg"),
        
        Lakes(titles: "Joe Pool Lake", location: "Cedar Hill, TX", address: "5610 Lake Ridge Pkwy., Grand Prairie, TX 75052", image: "Joepool.jpeg"),
        
        Lakes(titles: "Cedar Creek Reservoir",location: "Cedar Hill, TX" ,address: "2101 E Cedar Creek Parkway, Cedar Creek, TX", image: "cedarcreek.jpeg"),
        
        Lakes(titles: "Lake Arlington", location: "Arlington, TX", address: "6300 W. Arkansas Lane, Arlington, TX 76016", image: "arlington.jpeg"),
        
        Lakes(titles: "Lewisville Lake",location: "Lewisville, TX", address: "600 Sandy Beach Road Lewisville, TX 75057", image: "lewisville.jpeg"),
        
        Lakes(titles: "Lavon Lake", location:"Collin County, TX", address: "1625 Brockdale Park Rd. Allen, TX 75002", image: "Lavon.jpeg")
    
    ]
    

    
        
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return addressBook.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        cell.imageCell.image = UIImage(named: addressBook[indexPath.row].image)
        cell.addressLabel.text = addressBook[indexPath.row].location
        cell.titleLabel.text = addressBook[indexPath.row].titles
        tableView.deselectRow(at: indexPath, animated: true)
        
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showMap" {
            if let indexPath = tableView.indexPathForSelectedRow{
            let destinationController = segue.destination as! MapViewController
            destinationController.Lake = addressBook[indexPath.row]
            }
        }
    }
    
    @IBAction func close(segue: UIStoryboardSegue){ }

    
    
    
    
}

